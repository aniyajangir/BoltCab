package com.anil.boltcab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoltcabApplicationTests {

	@Test
	void contextLoads() {
	}

}
