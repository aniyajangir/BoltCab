package com.anil.boltcab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoltcabApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoltcabApplication.class, args);
	}

}
