package com.anil.boltcab;

public enum Role {
	USER, DRIVER, ADMIN;
}
